package com.example.layoutmanagement.service;

import com.example.layoutmanagement.entity.Layout;
import com.example.layoutmanagement.entity.User;
import com.example.layoutmanagement.entity.UserLayout;
import com.example.layoutmanagement.exception.ResourceNotFoundException;
import com.example.layoutmanagement.repository.LayoutRepository;
import com.example.layoutmanagement.repository.UserLayoutRepository;
import com.example.layoutmanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserLayoutService {

    @Autowired
    private UserLayoutRepository userLayoutRepository;

    @Autowired
    private LayoutRepository layoutRepository;

    @Autowired
    private UserRepository userRepository;

    public UserLayout assignLayoutToUser(Long userId, Long layoutId, Integer groupId) {
        Optional<Layout> layout = layoutRepository.findById(layoutId);
        Optional<User> user = userRepository.findById(userId);

        if (!layout.isPresent()) {
            throw new ResourceNotFoundException("Layout not found");
        }

        if (!user.isPresent()) {
            throw new ResourceNotFoundException("User not found");
        }

        // Check for existing assignments and update if necessary
        Optional<UserLayout> existingAssignment = userLayoutRepository.findByUserId(userId);
        if (existingAssignment.isPresent()) {
            existingAssignment.get().setLayout(layout.get());
            return userLayoutRepository.save(existingAssignment.get());
        }

        // Create a new assignment
        UserLayout userLayout = new UserLayout();
        userLayout.setUser(user.get());
        userLayout.setLayout(layout.get());
        userLayout.setGroupId(groupId);

        return userLayoutRepository.save(userLayout);
    }

    public Optional<UserLayout> getLayoutByUser(Long userId) {
        return userLayoutRepository.findByUserId(userId);
    }

    public Optional<UserLayout> getLayoutByGroup(Integer groupId) {
        return userLayoutRepository.findByGroupId(groupId);
    }

    // Other service methods can be added here
}
