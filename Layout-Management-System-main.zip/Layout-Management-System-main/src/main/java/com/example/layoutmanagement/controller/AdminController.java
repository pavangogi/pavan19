package com.example.layoutmanagement.controller;

import com.example.layoutmanagement.entity.Layout;
import com.example.layoutmanagement.service.LayoutService;
import com.example.layoutmanagement.service.UserLayoutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private LayoutService layoutService;

    @Autowired
    private UserLayoutService userLayoutService;

    // GET API to display list of available layouts for the admin
    @GetMapping("/layouts")
    public ResponseEntity<List<Layout>> getLayouts() {
        List<Layout> layouts = layoutService.getAllLayouts();
        return ResponseEntity.ok(layouts);
    }

    // POST API to assign selected layout to user/user groups
    @PostMapping("/assign-layout")
    public ResponseEntity<String> assignLayout(@RequestParam Long userId, @RequestParam Long layoutId, @RequestParam(required = false) Integer groupId) {
        userLayoutService.assignLayoutToUser(userId, layoutId, groupId);
        return ResponseEntity.ok("Layout assigned successfully.");
    }

    // UPDATE API to change the layout
    @PutMapping("/change-layout")
    public ResponseEntity<String> changeLayout(@RequestParam Long userId, @RequestParam Long newLayoutId) {
        userLayoutService.assignLayoutToUser(userId, newLayoutId, null);
        return ResponseEntity.ok("Layout updated successfully.");
    }
}
