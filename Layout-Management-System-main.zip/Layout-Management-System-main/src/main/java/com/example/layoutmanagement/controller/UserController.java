package com.example.layoutmanagement.controller;

import com.example.layoutmanagement.entity.Layout;
import com.example.layoutmanagement.entity.UserLayout;
import com.example.layoutmanagement.service.UserLayoutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserLayoutService userLayoutService;

    // GET API to fetch the layout details when user login
    @GetMapping("/layout")
    public ResponseEntity<Layout> getUserLayout(@RequestParam Long userId, @RequestParam(required = false) Integer groupId) {
        Optional<UserLayout> userLayout = userLayoutService.getLayoutByUser(userId);

        if (!userLayout.isPresent() && groupId != null) {
            userLayout = userLayoutService.getLayoutByGroup(groupId);
        }

        return userLayout.map(layout -> ResponseEntity.ok(layout.getLayout()))
                         .orElse(ResponseEntity.notFound().build());
    }
}
