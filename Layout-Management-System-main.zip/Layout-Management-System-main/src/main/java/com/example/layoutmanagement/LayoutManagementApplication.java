package com.example.layoutmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LayoutManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(LayoutManagementApplication.class, args);
    }
}

