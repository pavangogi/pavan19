package com.example.layoutmanagement.service;

import com.example.layoutmanagement.entity.Layout;
import com.example.layoutmanagement.repository.LayoutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LayoutService {

    @Autowired
    private LayoutRepository layoutRepository;

    public List<Layout> getAllLayouts() {
        return layoutRepository.findAll();
    }

    // Other service methods can be added here
}
